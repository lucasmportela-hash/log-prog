# Minecraft 3D em Python

Versão simplificada de Minecraft criada em Python com o motor 3D Ursina,
como mostrado no vídeo. Você pode explorar o cenário, colocar e quebrar
blocos e escolher entre quatro cores.

## Como executar

Tenha o Python instalado. Na pasta do repositório, execute:

```bash
python -m pip install -r requirements.txt
python minecraft.py
```

No Windows, se o comando `python` não funcionar, use `py` no lugar dele.

Use **W, A, S e D** para andar, o **mouse** para olhar e **espaço** para
pular. O botão direito coloca um bloco e o esquerdo quebra o bloco na mira.
Use as teclas **1 a 4** para escolher a cor do próximo bloco.

## Código passo a passo

O arquivo `minecraft.py` contém o jogo completo. A pasta `passos/` mostra
as cinco versões executáveis apresentadas no vídeo: chão, jogador, colocar
blocos, quebrar blocos e escolher a cor.

## Aprenda Python do zero

Quer aprender Python do zero? Conheça o [curso completo de Python](https://academify.com.br/#github-ursina-minecraft).
