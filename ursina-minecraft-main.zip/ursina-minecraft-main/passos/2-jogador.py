from ursina import *
from ursina.prefabs.first_person_controller \
    import FirstPersonController

app = Ursina()
Sky()

for x in range(16):
    for z in range(16):
        Entity(model='cube', color=color.lime,
               texture='white_cube',
               position=(x, 0, z), collider='box')

jogador = FirstPersonController(position=(8, 1, 2))
app.run()
