from ursina import *

app = Ursina()
Sky()

for x in range(16):
    for z in range(16):
        Entity(model='cube', color=color.lime,
               texture='white_cube',
               position=(x, 0, z), collider='box')

camera.position = (7.5, 30, -14)
camera.rotation_x = 55
app.run()
